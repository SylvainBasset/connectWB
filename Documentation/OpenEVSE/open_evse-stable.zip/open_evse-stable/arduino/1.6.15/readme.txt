drop boards.local.txt and programmers.txt into <user>/AppData/Local/Arduino15/packages/hardware/avr/1.6.15.
-> overwrites existing programmers.txt
